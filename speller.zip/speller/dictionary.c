// Implements a dictionary's functionality

#include <stdbool.h>
#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "dictionary.h"
#include <strings.h>
#include <stdlib.h>

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;
// implementing a hash function
node *head = NULL;
node *hashtable [1000];
int hashtable_size = 1000;
int wordcount;

int hashfunction(const char* key)
{
    int index = 0;

    for (int i = 0; key[i] != '\0'; i++)
    {
        index += toupper(key[i]);
    }
    return index % hashtable_size;
}
// Returns true if word is in dictionary else false
bool check(const char *word)
{
    int hashes = hashfunction(word);
    
    if (hashtable[hashes] == NULL)
    {
        
        return false;
        
    }
    
    else if (hashtable[hashes] != NULL)
    {
        node *tmp_node1 = hashtable[hashes];
        
        while (tmp_node1 != NULL)
        {
            int i;
            i = strcasecmp(tmp_node1 -> word, word);
            if (i == 0)
            {
                return true;
            }
            else
            {
                tmp_node1 = tmp_node1 -> next;
            }
        }
    }
    return false;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    FILE *fp = fopen(dictionary, "r");
    if (fp == NULL)
    {
    return false;
    }

    char word[LENGTH + 1];

    wordcount = 0;

    while (fscanf (fp, "%s", word) != EOF)
    {
        node *tmp_node2 = malloc(sizeof(node));

        memset(tmp_node2, 0, sizeof(node));

        if(tmp_node2 == NULL)
        {
            unload();
            return false;
        }

        wordcount++;

        strcpy(tmp_node2 -> word, word);

        int hash = hashfunction(word);

        if(hashtable[hash] == NULL)
        {
            hashtable[hash] = tmp_node2;
            head = tmp_node2;
        }
        else
        {
            tmp_node2 -> next = hashtable[hash];
            hashtable[hash] = tmp_node2;
            head = tmp_node2;
        }
    }

        fclose (fp);
        return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    return wordcount;;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    
    for (int i = 0; i < hashtable_size; i++)
    {
        if (hashtable[i] != NULL)
        {
            node *tmp_node1 = hashtable[i];
            while (tmp_node1 != NULL)
            {
                node *temporary = tmp_node1;
                tmp_node1 = tmp_node1 -> next;
                free(temporary);            
            }
        }
    } 
    return true;
}
